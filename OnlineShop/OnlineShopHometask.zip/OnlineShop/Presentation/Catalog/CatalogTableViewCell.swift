//
//  CatalogTableViewCell.swift
//  OnlineShop
//
//  Created by Данил Терлецкий on 13.02.2023.
//

import UIKit

class CatalogTableViewCell: UITableViewCell {

    @IBOutlet weak var goodNameLabel: UILabel!
}
